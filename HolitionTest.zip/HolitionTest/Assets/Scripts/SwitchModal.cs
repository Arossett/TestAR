﻿using UnityEngine;
using System.Collections;

public class SwitchModal : MonoBehaviour {
	public GameObject[] markers;
	// Use this for initialization
	void Start () {
		markers = GameObject.FindGameObjectsWithTag("Marker");

	}

	public void activateModal(GameObject o){
		foreach(GameObject g in markers){
			g.SetActive(false);
		}
		o.SetActive(true);
	}
}
