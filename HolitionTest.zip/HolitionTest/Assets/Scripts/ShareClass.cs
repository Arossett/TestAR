﻿using UnityEngine;
using System.Collections;

public class ShareClass : MonoBehaviour {

	// Use this for initialization
	public void shareFB () {
		AndroidJavaClass jc = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
		AndroidJavaObject jo = jc.GetStatic<AndroidJavaObject>("currentActivity");

		// Invoke the "showMessage" method in our Android Plugin Activity
		jo.Call("shareStatusFacebook");
	}

	// Use this for initialization
	public void shareTwitter () {
		AndroidJavaClass jc = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
		AndroidJavaObject jo = jc.GetStatic<AndroidJavaObject>("currentActivity");

		// Invoke the "showMessage" method in our Android Plugin Activity
		jo.Call("shareTwitter");
	}

}
